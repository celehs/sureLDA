#' Simulated Dataset
#' 
#' Click \href{https://github.com/celehs/sureLDA/blob/master/sim/simdata.R}{HERE} to view details.
#' 
#' @examples 
#' str(simdata)
"simdata"
